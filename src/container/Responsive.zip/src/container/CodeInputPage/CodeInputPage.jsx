import React, { useEffect, useState } from "react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { tomorrow } from "react-syntax-highlighter/dist/esm/styles/prism";
import copy from "clipboard-copy";
import { IoIosLink } from "react-icons/io";
import client from "../../lib/client";
import "./CodeInput.css"
import { PropagateLoader } from "react-spinners";

const CodeInputPage = () => {
  const [code, setCode] = useState("");
  const [isCopied, setIsCopied] = useState(false);
  const [isText, setIsText] = useState(false);
  const [isNotFill, setIsNotFill] = useState(false);
  const [isNotCode, setIsNotCode] = useState(false);
  const [isClear, setIsCleared] = useState(false);
  const [linkColor, setLinkColor] = useState("text-white");
  const [showLivePreview, setShowLivePreview] = useState(false);
  const [showLiveButton, setShowLiveButton] = useState(true);
  const [postCodes, setPostCodes] = useState([]);

 const handleCopyClick = (codeToCopy) => {
   if (codeToCopy === "") {
     setIsNotFill(true);
     setTimeout(() => {
       setIsNotFill(false);
     }, 2000);
   } else {
     copy(codeToCopy);
     setIsCopied(true);
     setShowLivePreview(false);
     setLinkColor("text-[#00ff29]");

     // Reset the "Copied!" message after 2 seconds
     setTimeout(() => {
       setIsCopied(false);
       setLinkColor("text-white");
     }, 2000);
   }
 };

 const handleeditedcode = ()=>{
  copy(code)
  setIsText(true)
  setTimeout(()=>{
    setIsText(false)
  },2000)
 }


  const handlebuttonPreview = () => {
    if(code === ""){
       setIsNotCode(true);
       setTimeout(() => {
         setIsNotCode(false);
       }, 2000);
    }else{

      setShowLivePreview(true);
      setShowLiveButton(false);
    }
  };

  const handleClear = () => {
    setCode("");
    setIsCleared(true);
    setIsCopied(false); // Reset isCopied when clearing
    setShowLiveButton(true);
    setShowLivePreview(false);
    setTimeout(() => {
      setIsCleared(false);
    }, 2000);
  };

  useEffect(() => {
    client
      .fetch(
        `*[_type == "react"]{
      name,
      code,
      desc,
     }`
      )
      .then((data) => {
        setPostCodes(data);
        //  console.log(postCode);
      })
      .catch(console.error);
  }, []);

  return (
    <>
      {postCodes.length === 0 && (
        <div className="w-screen h-screen flex justify-center items-center">
          <PropagateLoader color="#36d7b7" size={20} />
        </div>
      )}
      <div className="min-h-screen flex items-center justify-center  w-[80vw] text-black mx-auto mt-24">
        <div className="p-4 w-full">
          <div className="mb-6">
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Enter your code here..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500"
              rows="6"
            />
            {showLiveButton && (
              <button
                onClick={handlebuttonPreview}
                className="bg-blue-500 text-white px-4 py-2 rounded-md mr-2"
              >
                Show Live Preview
              </button>
            )}
            {isNotCode && (
              <span className="text-green-500 text-sm">code is Empty!</span>
            )}
          </div>
          <div className="flex items-center ">
            <button
              onClick={handleeditedcode}
              className="bg-blue-500 text-white px-4 py-2 rounded-md mr-2"
            >
              {isText ? "Copied!" : "Copy"}
            </button>
            {isText && <span className="text-green-500 text-sm">Copied!</span>}
            <button
              onClick={handleClear}
              className="bg-blue-500 text-white px-4 py-2 rounded-md mr-2"
            >
              {isClear ? "Cleared!" : "Clear"}
            </button>
            {isClear && (
              <span className="text-green-500 text-sm">cleared!</span>
            )}
          </div>
          {showLivePreview && (
            <div className="live-preview mt-2">
              <iframe
                title="Live Preview"
                className="w-full h-40 border  bg-white rounded-md"
                srcDoc={code}
              />
            </div>
          )}
          <div className="relative">
            {isCopied && (
              <span className="text-green-500 text-sm absolute right-6 top-0">
                Code copied to clipboard!
              </span>
            )}
            {isNotFill && (
              <span className="text-green-500 text-sm absolute right-6 top-0">
                Code is Empty!
              </span>
            )}
            <IoIosLink
              onClick={() => handleCopyClick(code)}
              className={`absolute right-0 top-0 cursor-pointer  ${linkColor}  text-[26px]`}
            />

            <SyntaxHighlighter language="jsx" style={tomorrow}>
              {code}
            </SyntaxHighlighter>
          </div>
          {postCodes.map((postCode) => (
            <>
              <h2>{postCode.name}</h2>
              <p>{postCode.desc}</p>
              <div className="mt-6 relative">
                {isCopied && (
                  <span className="text-green-500 text-sm absolute right-6 top-0">
                    Code copied to clipboard!
                  </span>
                )}
                {isNotFill && (
                  <span className="text-green-500 text-sm absolute right-6 top-0">
                    Code is Empty!
                  </span>
                )}
                <IoIosLink
                  onClick={() => handleCopyClick(postCode.code)}
                  className={`absolute right-0 top-0 cursor-pointer  ${linkColor}  text-[26px]`}
                />

                <SyntaxHighlighter language="jsx" style={tomorrow}>
                  {postCode.code}
                </SyntaxHighlighter>
              </div>
            </>
          ))}
        </div>
      </div>
    </>
  );
};

export default CodeInputPage;
