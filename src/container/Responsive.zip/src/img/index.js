export { default as bg } from "./bg.png"
export { default as phonebg } from "./phonebg.jpg";
export {default as user } from "./user.png"
export {default as work1 } from "./work-1.png"
export {default as work2 } from "./work-2.png"
export {default as work3 } from "./work-3.png"